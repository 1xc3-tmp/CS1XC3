/**
 * @file course.c
 * @author  Sharmin Ahmed <ahmes179@mcmaster.ca>
 * @version 1.0
 *
 * @section DESCRIPTION
 * Contains implementation of functions related to the Course struct.
 *
 */


#include "course.h"

#include <stdio.h>
#include <stdlib.h>

/**
 *  Adds a student to the course list.
 * 
 * @param course: the Course to add the student to.
 * @param student: the Student to add to the Course.
 * @return nothing.
 */
void enroll_student(Course * course, Student * student)
{
    // increases the number of students in the course
    // and if this is above 1, use realloc to re-allocate space
    // for the students array. If not, simply use calloc for the first time.
	course->total_students++;
	if (course->total_students == 1)
	{
		course->students = calloc(1, sizeof(Student));
	}
	else
	{
		course->students =
		    realloc(course->students, course->total_students * sizeof(Student));
	}
	course->students[course->total_students - 1] = *student;
}

/**
 *  Prints out all information related to a course.
 * 
 * @param course: the Course who's information to print out.
 * @return nothing.
 */
void print_course(Course * course)
{
    // prints out all the members of the given Course, using printf()
	printf("Name: %s\n", course->name);
	printf("Code: %s\n", course->code);
	printf("Total students: %d\n\n", course->total_students);
	printf("****************************************\n\n");
	for (int i = 0; i < course->total_students; i++)
		print_student(&course->students[i]);
}

/**
 * Finds the student with the highest grade.
 * 
 * @param course: the Course to search in.
 * @return a pointer to the Student struct with the highest grade
 */
Student * top_student(Course * course)
{
	if (course->total_students == 0) return NULL;

	double    student_average = 0;
	double    max_average     = average(&course->students[0]);
	Student * student         = &course->students[0];

    // loops through each student in the course and finds who has
    // the highest average
	for (int i = 1; i < course->total_students; i++)
	{
		student_average = average(&course->students[i]);
		if (student_average > max_average)
		{
			max_average = student_average;
			student     = &course->students[i];
		}
	}

	return student;
}

/**
 * Finds the number of students who are passing the course.
 * 
 * @param course: the Course to look at.
 * @param total_passing: a pointer to the place the store the number of passing students.
 * @return all Students which are passing, in a pointer-array.
 */
Student * passing(Course * course, int * total_passing)
{
	int       count   = 0;
	Student * passing = NULL;

    // finds the number of students who have an average of 50 or higher
	for (int i = 0; i < course->total_students; i++)
		if (average(&course->students[i]) >= 50) count++;
        
	passing = calloc(count, sizeof(Student));
    
    // append each passing student to the above dynamic array of passing students
	int j = 0;
	for (int i = 0; i < course->total_students; i++)
	{
		if (average(&course->students[i]) >= 50)
		{
			passing[j] = course->students[i];
			j++;
		}
	}

	*total_passing = count;

	return passing;
}
