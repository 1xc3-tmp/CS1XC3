/**
 * @file course.h
 * @author  Sharmin Ahmed <ahmes179@mcmaster.ca>
 * @version 1.0
 *
 * @section DESCRIPTION
 * Header file defining the Course datatype and related functions
 *
 */

#include "student.h"

#include <stdbool.h>

/**
 * Stores information about a course: course name, code, students
 */
typedef struct _course
{
	char      name[100];    /**< name of the course, up to 100 characters.  */
	char      code[10];     /**< course code    */
	Student * students;     /**< the students in the course, in a pointer-array */
	int       total_students;   /**< number of students in the course   */
} Course;

/**
 *  Adds a student to the course list.
 * 
 * @param course: the Course to add the student to.
 * @param student: the Student to add to the Course.
 * @return nothing.
 */
void      enroll_student(Course * course, Student * student);

/**
 *  Prints out all information related to a course.
 * 
 * @param course: the Course who's information to print out.
 * @return nothing.
 */
void      print_course(Course * course);

/**
 * Finds the student with the highest grade.
 * 
 * @param course: the Course to search in.
 * @return a pointer to the Student struct with the highest grade
 */
Student * top_student(Course * course);

/**
 * Finds the number of students who are passing the course.
 * 
 * @param course: the Course to look at.
 * @param total_passing: a pointer to the place the store the number of passing students.
 * @return all Students which are passing, in a pointer-array.
 */
Student * passing(Course * course, int * total_passing);
