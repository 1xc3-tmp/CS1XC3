/**
 * @file main.c
 * @author  Sharmin Ahmed <ahmes179@mcmaster.ca>
 * @version 1.0
 *
 * @section DESCRIPTION
 * Driver code for the Student and Course data structures.
 *
 */


#include "course.h"
#include "time.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * The entrypoint to the driver code.
 * 
 * @return EXIT_SUCCESS upon completion of testing data structures
 */
int main(void)
{
	srand((unsigned)time(NULL));    // generate a random pseudo random
                                    // seed for rand() to use using system time

    // create a sample course and fill it with data
	Course * MATH101 = calloc(1, sizeof(Course));
	strcpy(MATH101->name, "Basics of Mathematics");
	strcpy(MATH101->code, "MATH 101");

	for (int i = 0; i < 20; i++)
		enroll_student(MATH101, generate_random_student(8));

	print_course(MATH101);

    // print out the top student of the above class
	Student * student;
	student = top_student(MATH101);
	printf("\n\nTop student: \n\n");
	print_student(student);

    // print out each student that is passing the course
	int       total_passing;
	Student * passing_students = passing(MATH101, &total_passing);
	printf("\nTotal passing: %d\n", total_passing);
	printf("\nPassing students:\n\n");
	for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);

	return EXIT_SUCCESS;
}
