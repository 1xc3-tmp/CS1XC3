/**
 * @file student.h
 * @author  Sharmin Ahmed <ahmes179@mcmaster.ca>
 * @version 1.0
 *
 * @section DESCRIPTION
 * Header file defining the Student datatypes and related functions.
 *
 */

/**
 * Stores information about a student: first and last name, ID, grades.
 * 
 */
typedef struct _student // shouldn't names with underscores be avoided since they are used for system-level things?
{
	char     first_name[50];    /**< the student's first name, up to 49 characters */
	char     last_name[50];     /**< the student's last name, up to 49 characters   */
	char     id[11];            /**< the student's identification code  */
	double * grades;            /**< the student's marks, in a pointer-array    */
	int      num_grades;        /**< the number of marks the student has    */
} Student;

/**
 *  Adds a grade to the student's list of grades.
 * 
 * @param student: the student to add the grade to.
 * @param grade: the grade to add.
 * @return nothing.
 */
void      add_grade(Student * student, double grade);

/**
 *  Calculate the average of the student's grades.
 * 
 * @param student: the student whose grades to average.
 * @return the average grade.
 */
double    average(Student * student);

/**
 *  Prints out all the information on a student.
 * 
 * @param student: the student whose information to print out
 * @return nothing
 */
void      print_student(Student * student);

/**
 *  Creates a random student (with a random name and ID)
 * 
 * @param the number of grades to give to the student
 * @return a pointer to the random Student struct
 */
Student * generate_random_student(int grades);
